# absolutePowershell - Release Notes

**1.7**
	- Initial public release

**1.71** 
	- Minor bug fixes

**1.8** 
	- Improved error handling for HTTP calls
	- Added Convert-UnixDateTime
